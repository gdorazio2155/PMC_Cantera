This directory is for applications that are not part of Cantera
itself, but may be distributed with Cantera.

Contents:

MixMaster --  A graphical control panel for viewing mixture properties 
              (Python)

