function i = reactor_hndl(r)
i = r.index;
