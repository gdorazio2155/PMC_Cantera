function t = time(r)
% TIME - time
%   
t = reactormethods(22, reactor_hndl(r));
