function rho = density(r)
% DENSITY - density
%   
rho = reactormethods(25, reactor_hndl(r));
