function t = temperature(r)
% TEMPERATURE - temperature
%   
t = reactormethods(26, reactor_hndl(r));

