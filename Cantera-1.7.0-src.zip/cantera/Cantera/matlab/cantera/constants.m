function [atm,r] = constants
atm = 101325.0;
r      = 8314.0;
