function cleanup()
% CLEANUP - Delete all stored Cantera objects and reclaim memory 
%   
ctmethods(0, 4);
