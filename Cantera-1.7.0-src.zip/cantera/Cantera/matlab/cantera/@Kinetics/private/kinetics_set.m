function kinetics_set(n, job, a, b)
% KINETICS_SET - get kinetics attributes 
%   
ctmethods(40, n, -job, a, b)


