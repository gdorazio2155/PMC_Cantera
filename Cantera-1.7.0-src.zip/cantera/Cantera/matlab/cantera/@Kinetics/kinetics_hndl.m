function i = kinetics_hndl(k)
% KINETICS_HNDL - integer used to access kernel object
%   
i = k.id;


