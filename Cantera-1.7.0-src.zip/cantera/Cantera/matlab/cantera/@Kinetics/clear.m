function clear(k)
% CLEAR - delete the Kinetics instance.
%   
kinetics_set(k.id,3);

