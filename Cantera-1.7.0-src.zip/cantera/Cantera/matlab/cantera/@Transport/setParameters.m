function setParameters(tr, type, k, p)
% SETPARAMETERS - set parameters.
%   
v = trans_get(tr.id, 31, type, k, p);

