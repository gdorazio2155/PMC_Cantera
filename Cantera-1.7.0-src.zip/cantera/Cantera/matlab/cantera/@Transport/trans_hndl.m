function n = trans_hndl(a)
n = a.id;
