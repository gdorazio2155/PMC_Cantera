function n = addChild(root, id)
%   
n = ctmethods(10, 10, root.id, id);
