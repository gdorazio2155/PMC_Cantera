function write(x, file)

ctmethods(10, 13, x.id, file);

