function display(self)
phase_get(thermo_hndl(self), 15, 1);

