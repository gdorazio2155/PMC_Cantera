function i = thermo_hndl(p)
i = p.tp_id;
