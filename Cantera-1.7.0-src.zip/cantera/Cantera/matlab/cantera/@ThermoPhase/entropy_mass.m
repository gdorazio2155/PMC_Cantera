function v = entropy_mass(a)
v = thermo_get(a.tp_id,11);
