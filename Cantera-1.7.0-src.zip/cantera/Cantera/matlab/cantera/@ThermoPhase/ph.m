function i = ph(t)
disp('method ph is deprecated.');
i = t.ph;
