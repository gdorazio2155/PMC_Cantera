function n = nElements(a)
% NELEMENTS - Number of elements in the phase.
%
n = phase_get(a.tp_id,10);