function v = entropy_mole(a)
v = thermo_get(a.tp_id,4);
