function clear(t)
% CLEAR - Delete the kernel object.
%   
thermo_set(t.tp_id,0,10);

