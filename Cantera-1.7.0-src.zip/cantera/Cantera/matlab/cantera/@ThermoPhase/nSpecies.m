function n = nSpecies(a)
% NSPECIES - Number of species in the phase.
%
n = phase_get(a.tp_id,11);