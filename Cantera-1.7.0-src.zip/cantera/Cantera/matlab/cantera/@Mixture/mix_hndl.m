function i = mix_hndl(self)
% MIX_HNDL - integer used to access kernel object
%   
i = self.mixindex;


