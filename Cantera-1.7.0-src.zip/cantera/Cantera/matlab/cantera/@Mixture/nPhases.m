function n = nPhases(self)
% NPHASES - number of phases
%   
n = mixturemethods(19, mix_hndl(self));

