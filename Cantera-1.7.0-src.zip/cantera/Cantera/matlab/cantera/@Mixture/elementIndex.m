function n = elementIndex(self, name)
% ELEMENTINDEX - index of element with name 'name'
%   
n = mixturemethods(22, mix_hndl(self), name);

