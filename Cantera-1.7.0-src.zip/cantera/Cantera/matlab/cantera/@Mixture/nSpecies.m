function n = nSpecies(self)
% NSPECIES - number of species
%   
n = mixturemethods(24, mix_hndl(self));

