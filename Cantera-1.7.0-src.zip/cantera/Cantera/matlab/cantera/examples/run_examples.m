
% runs all examples
equil(0);
disp('press any key to continue');
pause
isentropic(0);
disp('press any key to continue');
pause
reactor1(0);
disp('press any key to continue');
pause
reactor2(0);
disp('press any key to continue');
pause
surfreactor;
disp('press any key to continue');
pause
periodic_cstr;
disp('press any key to continue');
pause;
rankine(300.0, 2.0*oneatm, 0.8, 0.7);
disp('press any key to continue');
pause;
prandtl1(0);
disp('press any key to continue');
pause
prandtl2(0);
disp('press any key to continue');
pause
flame1
disp('press any key to continue');
pause
diffflame
disp('press any key to continue');
pause
catcomb
disp('press any key to continue');
pause
