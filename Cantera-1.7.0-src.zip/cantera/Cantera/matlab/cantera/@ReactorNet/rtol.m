function t = rtol(r)
% RTOL - relative error tolerance
%   
t = reactornetmethods(23, reactornet_hndl(r));

