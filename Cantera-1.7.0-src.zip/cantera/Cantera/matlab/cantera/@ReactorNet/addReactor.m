function addReactor(net, reactor)
% ADDREACTOR - Add a reactor to the network
reactornetmethods(4, reactornet_hndl(net), reactor_hndl(reactor));
