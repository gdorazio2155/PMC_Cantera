function t = atol(r)
% ATOL - absolute error tolerance
%   
t = reactornetmethods(24, reactornet_hndl(r));

