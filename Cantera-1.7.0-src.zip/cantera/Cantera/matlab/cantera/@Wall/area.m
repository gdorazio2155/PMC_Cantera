function a = area(w)
% AREA - 
%   
a = wallmethods(23, wall_hndl(w))

