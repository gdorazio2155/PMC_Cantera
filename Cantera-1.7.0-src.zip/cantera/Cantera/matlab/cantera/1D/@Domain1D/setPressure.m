function d = setPressure(d, p)
% SETPRESSURE - 
%   
domain_methods(d.dom_id, 63, p);

