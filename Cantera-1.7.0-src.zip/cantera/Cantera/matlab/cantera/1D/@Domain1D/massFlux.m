function mdot = massFlux(d)
% MASSFLUX - 
%   
mdot = domain_methods(d.dom_id, 17);

