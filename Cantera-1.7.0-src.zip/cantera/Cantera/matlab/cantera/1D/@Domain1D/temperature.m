function t = temperature(d)
% TEMPERATURE - Temperature [K].
%   
t = domain_methods(d.dom_id, 15);

