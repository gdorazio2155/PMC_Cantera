function n = domain_hndl(d)
% DOMAIN_HNDL - Integer used to access kernel object.
%   
n = d.dom_id;

