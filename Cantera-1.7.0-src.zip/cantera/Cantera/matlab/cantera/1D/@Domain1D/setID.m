function d = setID(d, id)
% SETID - Set the ID tag for the domain.
%   
domain_methods(d.dom_id, 54, id);
