function npts = nPoints(d)
% NPOINTS - Number of grid points.
%   
npts = domain_methods(d.dom_id, 14);

