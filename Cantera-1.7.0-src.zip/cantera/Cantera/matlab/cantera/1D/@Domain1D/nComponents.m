function n = nComponents(d)
% NCOMPONENTS - number of components
%   
n = domain_methods(d.dom_id, 11);
