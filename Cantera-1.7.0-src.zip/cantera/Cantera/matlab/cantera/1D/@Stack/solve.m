function solve(s, loglevel, refine_grid)
% SOLVE - 
%   
stack_methods(s.stack_id, 104, loglevel, refine_grid);

