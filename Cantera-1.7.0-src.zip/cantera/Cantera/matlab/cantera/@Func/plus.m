function r = plus(a, b)
%
% PLUS - Return a functor representing the sum of two functors a
% and b.
%   
r = Func('sum',a,b);


