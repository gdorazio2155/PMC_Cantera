#ifndef CXX_EDGE
#define CXX_EDGE

#include <string>

#include "kernel/EdgePhase.h"
#include "kernel/EdgeKinetics.h"
#include "kernel/importCTML.h"

namespace Cantera {

    class Edge : 
        public EdgePhase, public EdgeKinetics
    {
    public:
        Edge(string infile, string id, vector<ThermoPhase*> phases) 
            : m_ok(false), m_r(0) {

            m_r = get_XML_File(infile); 
            if (id == "-") id = "";

            XML_Node* x = get_XML_Node("#"+id, m_r);
            if (!x)                 
                throw CanteraError("Edge","error in get_XML_Node");

            importPhase(*x, this);
            phases.push_back(this);
            importKinetics(*x, phases, this);
            m_ok = true;
        }


        virtual ~Edge() {}

        bool operator!() { return !m_ok;}
        bool ready() { return m_ok; }

    protected:
        bool m_ok;
        XML_Node* m_r;

    private:
    };
}


#endif
